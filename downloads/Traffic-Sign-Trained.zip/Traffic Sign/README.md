# Traffic Sign — trained printed-sign prototype

This version includes a genuinely trained four-class YOLOv10n model for STOP, No Entry, Compulsory Left and Compulsory Right, plus the camera-to-driving integration and dashboard. Training uses generated images resembling the supplied printed STOP sign and the included sign cards, varied backgrounds, close-up views, perspective, blur and hard negatives.

**Scope:** this is a controlled printed-sign prototype. Synthetic held-out results are not proof of physical camera accuracy or safe stopping distance. The model must be checked on stationary Pi camera images before a moving-car demonstration. Read `MODEL_CARD.md` for the actual training and evaluation results and remaining limitations.

## What is included

- `models/traffic_signs.pt`: trained four-class checkpoint.
- `models/traffic_signs_ncnn_model/`: verified FP16 NCNN export for deployment.
- `printable_cards/`: the four sign cards to print for initial controlled-track checks.
- `detect.py`: image/video/webcam recognition without any motor controller.
- `run.py`, `car/`: integrated camera, sign decisions, lane/follow behavior and dashboard.
- `training/`: reproducible generation, training and evaluation scripts.
- `training_samples/`: examples actually used in training, YOLO labels and preview.
- `tests/`: software regression tests; their simulated hardware is not a physical driving test.

## 1. Check recognition with motors disconnected

Keep this `Traffic Sign` folder inside the model-car-capstone repository. Use the repository's Python environment and camera setup. From the repository root:

```bash
python -m pip install -r "Traffic Sign/car/requirements.txt"
python "Traffic Sign/detect.py" --source "Traffic Sign/printable_cards/stop.png" --output stop-check
```

Inspect `stop-check/annotated.jpg` and `stop-check/detections.json`. Then photograph the **actual printed** card at representative distances and lighting, and run the same command using your photograph. A digital card passing does not replace that check.

For a saved video, replace `--source` with its filename. For an OpenCV webcam use `--source 0 --max-frames 120`. This standalone checker does not open a serial motor link. Its webcam path is OpenCV; the car runtime below is the Picamera2 CSI path on the Pi.

Bundled NCNN weights are selected when the NCNN runtime is installed; otherwise the local `.pt` is selected. `--model /absolute/path/to/model.pt` overrides the standalone checker. No weights are downloaded silently.

## 2. Inspect the Pi camera and dashboard

```bash
python "Traffic Sign/run.py" --mode lane --bench-safe
```

For person following, use `--mode follow --bench-safe` and select/calibrate the owner through the existing dashboard. Sign recognition is now available in follow mode as well. After a sign stop or turn, the learned owner profile is retained but the tracker must reacquire the target rather than reuse stale tracking.

The runtime enables the bundled model by default. Missing weights produce a clear startup error. `--traffic-sign-model PATH` selects other compatible weights; `--disable-traffic-signs` explicitly restores operation without sign handling. The latter means STOP prints are **not** traffic instructions.

The dashboard shows detected sign, bearing, instruction, action and faults, with boxes on the camera stream. `--bench-safe` initially disables motion; it is a software setting, not a physical power interlock.

## 3. Controlled-track movement

Only after stationary recognition, motor direction, sonar and turn calibration have been checked, remove `--bench-safe` for a controlled track run:

```bash
python "Traffic Sign/run.py" --mode lane --traffic-turn-pwm 210 --traffic-turn-ms-per-degree 10
```

These motor settings follow the repository's documented starting values, not fresh measurements. Timing must match the Uno's actual `TURN_CAL`. Ordinary obstacle protection keeps priority; a person or print board blocking the path can keep the car stopped independently of the sign instruction.

| Sign | Action |
|---|---|
| STOP | Three fresh confirmations, command STOP, accumulate three seconds commanded stopped, then allow existing safety checks to govern resuming. |
| No Entry | Stop until explicit sign-policy reset. |
| Left / Right | Confirm, approach, then automatically turn when the apparent-size/bearing gate and safety conditions are satisfied. |

In lane mode, bounded turn pulses must observe lane departure and then reacquire the centered corridor. Timeout/interruption holds a fault until reset. In autonomous/follow modes, sign turns are timed; actual yaw is unverified because the current IMU heading is a stub. The sign approach gate is not a general junction detector or metric ranging system. Place consistent-size signs at calibrated decision points.

The car still needs its existing general obstacle and pothole models in the repository's `benchmarking/models/` and `pothole_detection/` paths. This folder resolves those shared assets from the repository root. Read `GUIDE.md` for detailed behavior.

## Training and tests

The download also provides a separate archive of the generated train/validation/test images and labels. Edit its dataset.yaml path after extracting elsewhere. The source generator uses the existing repository videos for backgrounds and procedural backgrounds, with separate splits. No actual Pi-camera training or test photographs were supplied.

From this folder, run software tests in your development environment:

```bash
python -m pytest -q tests
```

For retraining, see `training/generate_dataset.py`, `training/train_model.py`, `training/evaluate_model.py` and the exact run details in `MODEL_CARD.md`. Do not horizontally flip directional arrows without changing their labels.
